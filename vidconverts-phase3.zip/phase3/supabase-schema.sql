-- Run this in your Supabase SQL editor
-- Go to: Supabase Dashboard → SQL Editor → New Query → paste this → Run

create table if not exists reports (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  video_name text,
  video_source text default 'upload',
  niche text not null,
  audience text not null,
  goal text not null,
  transcript text,
  report_data jsonb not null,
  tier text default 'free',
  created_at timestamptz default now()
);

-- Enable Row Level Security
alter table reports enable row level security;

-- Users can only see their own reports
create policy "Users can view own reports"
  on reports for select
  using (auth.uid() = user_id);

-- Users can insert their own reports
create policy "Users can insert own reports"
  on reports for insert
  with check (auth.uid() = user_id);

-- Users can delete their own reports
create policy "Users can delete own reports"
  on reports for delete
  using (auth.uid() = user_id);
