-- =====================================================
-- Vid Converts — Tags & Folders Migration
-- Run this in your Supabase SQL Editor
-- =====================================================

-- Add folder column to reports table
ALTER TABLE reports
  ADD COLUMN IF NOT EXISTS folder text DEFAULT NULL;

-- Add tags column to reports table (stored as text array)
ALTER TABLE reports
  ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}';

-- Index for fast folder filtering
CREATE INDEX IF NOT EXISTS idx_reports_folder ON reports (folder);

-- Index for fast tag filtering (GIN index for array search)
CREATE INDEX IF NOT EXISTS idx_reports_tags ON reports USING GIN (tags);

-- Done! No data migration needed — existing reports get NULL folder and empty tags array.
