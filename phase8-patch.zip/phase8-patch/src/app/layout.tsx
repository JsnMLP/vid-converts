import type { Metadata } from 'next'
import { Montserrat, Mulish } from 'next/font/google'
import './globals.css'

const montserrat = Montserrat({
  subsets: ['latin'],
  variable: '--font-display',
  weight: ['400', '500', '600', '700', '800', '900'],
  display: 'swap',
})

const mulish = Mulish({
  subsets: ['latin'],
  variable: '--font-body',
  weight: ['300', '400', '500', '600', '700', '800'],
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Vid Converts — Video Conversion Audit',
  description: 'Evidence-based video conversion audits for coaches, consultants, and service providers. Know exactly what to fix and why.',
  keywords: 'video audit, conversion optimization, marketing video, video analysis',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${montserrat.variable} ${mulish.variable}`}>
      <body>{children}</body>
    </html>
  )
}
